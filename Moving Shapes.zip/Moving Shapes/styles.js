var  shapes= [];
var pos= 500;
var x=x;
var y=y;
function setup() {
	createCanvas(800,600);
	for(var i=0; i<50; i++) {
		shapes.push(new shape(random(width),random(height),
			random(255), random(255), random(255)));
	}
}

function draw() {
	background(162,160,160);
	for(var i = 0; i<10; i++) {
		shapes[i].move();
		shapes[i].show();
	}

}

function shape(x, y, red, green, blue) {
	this.x = x;
	this.y = y;
	this.red = red;
	this.green = green;
	this.blue = blue;
	
	this.show = function() {if (mouseIsPressed){
		fill(this.red,this.green,this.blue);
		ellipse (this.x, pos, 50, 50);
	} else{
		fill(this.red,this.green,this.blue);
		rect (this.x, pos, 20, 20);
	}
	print(mouseIsPressed);
};
	

	this.move = function() {
		this.x += random(-5,5);
		this.y += random(5,-5);
	}
}
function mouseWheel(event){
	print(event.delta);

	pos += event.delta;
}


