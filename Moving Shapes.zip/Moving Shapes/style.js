var  shapes= [];

function setup() {
	createCanvas(640,480);
	
	for(var i=0; i<700; i++) {
		shapes.push(new shape(random(width),random(height),
			random(255), random(255), random(255)));
	}
}

function draw() {
	background(0,0,0);
	for(var i = 0; i<700; i++) {
		shapes[i].move();
		shapes[i].show();
	}

}

function shape(x, y, red, green, blue) {
	this.x = x;
	this.y = y;
	this.red = red;
	this.green = green;
	this.blue = blue;
	
	this.show = function() {
		fill(this.red,this.green,this.blue);
		ellipse (this.x, this.y, 20, 20);
		};
	

	this.move = function() {
		this.x += random(-5,5);
		this.y += random(20,-20);
	}
}